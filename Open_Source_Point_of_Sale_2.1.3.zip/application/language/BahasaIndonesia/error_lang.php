<?php
$lang['error_no_permission_module']='Anda tidak memiliki izin untuk mengakses modul ini';
$lang['error_unknown']='tidak dikenal';
?>