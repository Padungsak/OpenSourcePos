<?php
$lang['recvs_register']='Получение товаров';
$lang['recvs_mode']='получая режим';
$lang['recvs_receiving']='получать';
$lang['recvs_return']='возвращать';
$lang['recvs_total']='сумма';
$lang['recvs_cost']='стоимость';
$lang['recvs_quantity']='Кол-во.';
$lang['recvs_discount']='Скидка %';
$lang['recvs_edit']='редактировать';
$lang['recvs_new_supplier'] = 'Новый поставщик';
$lang['recvs_supplier'] = 'поставщик';
$lang['recvs_select_supplier']='Выберите поставщика (необязательно)';
$lang['recvs_start_typing_supplier_name']='Начните вводить название поставщика...';
$lang['recvs_unable_to_add_item']='Невозможно добавить товар на получение';
$lang['recvs_error_editing_item']='Ошибка редактирования товар';
$lang['recvs_receipt']='квитанция о получении';
$lang['recvs_complete_receiving']='заканчивать';
$lang['recvs_confirm_finish_receiving'] = 'Вы уверены, что хотите представить это получение? Это не может быть отменено.';
$lang['recvs_confirm_cancel_receiving'] = 'Вы уверены, что хотите удалить это получение? Все детали будут очищены.';
$lang['recvs_find_or_scan_item']='Найти/Сканировать товар';
$lang['recvs_find_or_scan_item_or_receipt']='Найти/Сканировать товар ИЛИ квитанция';
$lang['recvs_id']='получение ID';
$lang['recvs_item_name'] = 'Название товара';
$lang['receivings_transaction_failed'] = 'Ошибка Получение транзакции';
?>
